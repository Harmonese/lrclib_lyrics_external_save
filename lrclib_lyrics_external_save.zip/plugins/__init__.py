# Required for Picard to treat this folder as a plugin package.
